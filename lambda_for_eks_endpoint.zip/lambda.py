from distutils.util import strtobool
import json
import logging
import sys
import time
import random
from pip._internal import main
main(['install', 'boto3', '--target', '/tmp/'])
sys.path.insert(0, '/tmp/')
from botocore.vendored import requests
from botocore.exceptions import ClientError
import boto3

client = boto3.client('eks')
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def lambda_handler(event, context):
    print(event)
    # printing the Boto3 version being used
    print("Boto3 version = ", boto3.__version__)
    try:
        if event['RequestType'] == 'Delete':
            print("delete")
            responseStatus = 'SUCCESS'
            responseData = {'Success': 'Everything worked.'}
        elif event['RequestType'] == 'Create':
            print("Inside CREATE Request type")
            cluster_name = event['ResourceProperties']['clustername']
            endpbVal = event['ResourceProperties']['endpointPublicAccessValue']
            endprVal = event['ResourceProperties']['endpointPrivateAccessValue']
            desc_cluster = client.describe_cluster(name=cluster_name)
            if bool(strtobool(endpbVal)) == True and bool(strtobool(endprVal)) == False:
                print("Not peforming Endpoint Access Update as the given Values are default values")
                responseStatus = 'SUCCESS'
                responseData = {'Success': 'Everything worked.'}
            elif bool(strtobool(endpbVal)) == False and bool(strtobool(endprVal)) == False:
                print("Both Public and Private Endpoint cannot be set to False. Please refer here for more information : https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html#modify-endpoint-access")
                responseStatus = 'FAILED'
                responseData = {'Failure': 'Both Public and Private Endpoint cannot be set to False. Please refer here for more information : https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html#modify-endpoint-access'}
                print(responseData)
            else:
                response1 = client.update_cluster_config(name=cluster_name, resourcesVpcConfig={'endpointPublicAccess': bool(strtobool(endpbVal)), 'endpointPrivateAccess': bool(strtobool(endprVal))})
                print("Update Id for EKS Cluster", response1['update']['id'])
                n = 1
                while (n < 10):
                    response2 = client.describe_update(
                        name=cluster_name, updateId=response1['update']['id'])
                    if response2['update']['status'] == 'Successful':
                        print("End-point Access update is successful")
                        break
                    else:
                        time.sleep(60)
                    n = n + 1
                responseStatus = 'SUCCESS'
                responseData = {'Success': 'Everything worked.'}
        elif event['RequestType'] == 'Update':
            print("Inside UPDATE Request type")
            cluster_name = event['ResourceProperties']['clustername']
            endpbVal = event['ResourceProperties']['endpointPublicAccessValue']
            endprVal = event['ResourceProperties']['endpointPrivateAccessValue']
            desc_cluster = client.describe_cluster(name=cluster_name)
            desc_pbAccess = desc_cluster['cluster']['resourcesVpcConfig']['endpointPublicAccess']
            desc_prAccess = desc_cluster['cluster']['resourcesVpcConfig']['endpointPrivateAccess']
            if str(desc_pbAccess).lower() == endpbVal.lower() and str(desc_prAccess).lower() == endprVal.lower():
                print("Not peforming Endpoint Access Update as the given Values are equal to existing values")
                responseStatus = 'SUCCESS'
                responseData = {'Success': 'Everything worked.'}
            elif bool(strtobool(endpbVal)) == False and bool(strtobool(endprVal)) == False:
                print("Both Public and Private Endpoint cannot be set to False. Please refer here for more information : https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html#modify-endpoint-access")
                responseStatus = 'FAILED'
                responseData = {'Failure': 'Both Public and Private Endpoint cannot be set to False. Please refer here for more information : https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html#modify-endpoint-access'}
                print(responseData)
            else:
                response1 = client.update_cluster_config(name=cluster_name, resourcesVpcConfig={'endpointPublicAccess': bool(strtobool(endpbVal)), 'endpointPrivateAccess': bool(strtobool(endprVal))})
                print("Update Id for EKS Cluster", response1['update']['id'])
                n = 1
                while (n < 10):
                    response2 = client.describe_update(name=cluster_name, updateId=response1['update']['id'])
                    if response2['update']['status'] == 'Successful':
                        print("Endpoint-access-update is successful")
                        break
                    else:
                        time.sleep(60)
                    n = n + 1
                responseStatus = 'SUCCESS'
                responseData = {'Success': 'Everything worked.'}
    # Retry logic when the function execution fails with Throttling Exception.
    except ClientError as e:
        if e.response['Error']['Code'] == 'ThrottlingException':
            count = 3
            attempts = 0
            while attempts < count:
                logger.info("Retrying Function Execution...")
                lambda_handler(event, context)
                attempts += 1
                # Implementing exponential back-off
                time.sleep(random.expovariate(1))
        # Catching exception when domain was deleted out-of-band
        if event['RequestType'] == 'Delete' and e.response['Error']['Code'] == 'NotFoundException':
            logger.info("Resource was deleted out of band...")
            responseStatus = "SUCCESS"
            responseData = {}
        # All other exceptions fail with a FAILURE signal to CloudFormation.
        else:
            responseStatus = "FAILED"
            responseData = {}
            logger.info(
                "The resource creation failed with the error " + e.response['Error']['Code'])
    sendResponse(event, context, responseStatus, responseData)

def sendResponse(event, context, responseStatus, responseData, reason=None, physical_resource_id=None):
    responseBody = {'Status': responseStatus,
                    'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
                    'PhysicalResourceId': physical_resource_id or context.log_stream_name,
                    'StackId': event['StackId'],
                    'RequestId': event['RequestId'],
                    'LogicalResourceId': event['LogicalResourceId'],
                    'Data': responseData}
    # print 'RESPONSE BODY:n' + json.dumps(responseBody)
    responseUrl = event['ResponseURL']
    json_responseBody = json.dumps(responseBody)
    headers = {
        'content-type': '',
        'content-length': str(len(json_responseBody))
    }
    try:
        response = requests.put(responseUrl,
                                data=json_responseBody,
                                headers=headers)
        # print "Status code: " + response.reason
    except Exception as e:
        print(e)
        # print "send(..) failed executing requests.put(..): " + str(e)
